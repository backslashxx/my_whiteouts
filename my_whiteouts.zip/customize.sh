# put your whiteouts here
# one per line
REPLACE="
/system/priv-app/nfc
"
